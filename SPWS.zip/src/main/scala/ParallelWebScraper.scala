import org.jsoup.Jsoup
import java.io.File
import scala.concurrent.{Await, Future}
import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.duration._
import play.api.libs.json.{Json, Writes}
import scala.util.{Failure, Success, Try}
import scala.collection.mutable
import java.net.URL

object ParallelWebScraper extends App {

  final case class ScrapedData(url: String, title: Option[String], authors: Option[List[String]], abstractText: Option[String], publishedDate: Option[String], error: Option[String])

  implicit val scrapedDataWrites: Writes[ScrapedData] = Json.writes[ScrapedData]

  def scrapeUrl(url: String): Future[ScrapedData] = Future {
    try {
      val doc = Jsoup.connect(url).userAgent("Mozilla/5.0").timeout(10000).get()  
      val title = Option(doc.title()).filter(_.nonEmpty)
      val authors = Option(doc.select("meta[name=citation_author]").attr("content")).filter(_.nonEmpty).map(_.split(",").toList)
      val abstractText = Option(doc.select("meta[name=citation_abstract]").attr("content")).filter(_.nonEmpty)
      val publishedDate = Option(doc.select("meta[name=citation_publication_date]").attr("content")).filter(_.nonEmpty)
      ScrapedData(url, title, authors, abstractText, publishedDate, None)
    } catch {
      case e: Exception => ScrapedData(url, None, None, None, None, Some(e.getMessage))
    }
  }

  def scrapeParallel(inputFile: String): Unit = {
    val urls = scala.io.Source.fromFile(inputFile).getLines().toList
    val startTime = System.nanoTime()

    val scrapedFutures = urls.map { url =>
      scrapeUrl(url).recover {
        case ex: Exception => ScrapedData(url, None, None, None, None, Some(ex.getMessage))
      }
    }

    val aggregatedResults = Future.sequence(scrapedFutures)
    val results = Await.result(aggregatedResults, 20.seconds)

    val outputFile = new File("outputP.txt")
    val writer = new java.io.PrintWriter(outputFile)
    results.foreach { data =>
      writer.println(Json.toJson(data).toString())
      writer.println()
    }
    writer.close()

    val endTime = System.nanoTime()
    val duration = (endTime - startTime) / 1e9d
    println(s"All scraping tasks completed in $duration seconds. Results written to outputP.txt.")
  }

  val inputFile = args.headOption.getOrElse("input2.txt")
  scrapeParallel(inputFile)
}
